## ----knitr_setup, include=FALSE, message=FALSE--------------------------------
library(knitr)
opts_chunk$set(echo = TRUE)
rc <- knitr::read_chunk
rc(system.file("vignette_data","mcmc.R",package="glmmTMB"))


## ----libs,message=FALSE-------------------------------------------------------
library(glmmTMB)
library(coda)     ## MCMC utilities
library(reshape2) ## for melt()
## graphics
library(lattice)
library(ggplot2); theme_set(theme_bw())


## ----fit1---------------------------------------------------------------------


## ----setup--------------------------------------------------------------------


## ----run_MCMC-----------------------------------------------------------------


## ----do_run_MCMC,eval=FALSE---------------------------------------------------
## NA


## ----load_MCMC, echo=FALSE----------------------------------------------------
L <- load(system.file("vignette_data", "mcmc.rda", package="glmmTMB"))


## ----add_names----------------------------------------------------------------
colnames(m1) <- c(names(fixef(fm1)[[1]]),
                  "log(sigma)",
                  c("log(sd_Intercept)","log(sd_Days)","cor"))
m1[,"cor"] <- sapply(m1[,"cor"],get_cor)


## ----traceplot,fig.width=7----------------------------------------------------
xyplot(m1,layout=c(2,3),asp="fill")


## ----effsize------------------------------------------------------------------
print(effectiveSize(m1),digits=3)


## ----violins,echo=FALSE-------------------------------------------------------
ggplot(reshape2::melt(as.matrix(m1[,-1])),aes(x=Var2,y=value))+
         geom_violin(fill="gray")+coord_flip()+labs(x="")


## ----do_tmbstan,eval=FALSE----------------------------------------------------
## NA


## ----show_traceplot,echo=FALSE,fig.width=8,fig.height=5-----------------------
library(png)
library(grid)
img <- readPNG(system.file("vignette_data","tmbstan_traceplot.png",package="glmmTMB"))
grid.raster(img)

